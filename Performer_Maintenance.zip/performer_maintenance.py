import requests
import sys

# GraphQL endpoint URL
graphql_url = "http://localhost:9999/graphql"

# GraphQL query to find performers with no scenes
query = """
query FindPerformers {
  findPerformers(performer_filter: { scene_count: { value: 0, modifier: EQUALS } }) {
    performers {
      id
    }
  }
}
"""

# GraphQL mutation to destroy performers based on their IDs
mutation_template = """
mutation PerformerDestroy {
  performerDestroy(input: { id: "%s" })
}
"""

def run_query(query):
    response = requests.post(graphql_url, json={"query": query})
    return response.json()

def run_mutation(mutation):
    response = requests.post(graphql_url, json={"query": mutation})
    return response.json()

# Execute the query to find performers with no scenes
result = run_query(query)

# Check if there are performers found
if "data" in result and "findPerformers" in result["data"]:
    performers = result["data"]["findPerformers"]["performers"]

    if performers:
        print(f"Performers found with no scenes: {performers}")

        # Build and execute mutation for each performer
        for performer in performers:
            performer_id = performer["id"]
            mutation = mutation_template % performer_id
            mutation_result = run_mutation(mutation)

            if "data" in mutation_result and "performerDestroy" in mutation_result["data"]:
                print(f"Performer with ID {performer_id} has been deleted.")
            else:
                print(f"Failed to delete performer with ID {performer_id}. Check the mutation result.")
    else:
        print("No performers found with no scenes. Nothing to delete.")
else:
    print("Error in the GraphQL query result. Check the query and endpoint.")

if sys.stdin.isatty():
    sys.stdin.close()
